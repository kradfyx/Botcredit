-- ═══════════════════════════════════════════════════════════════
-- BotCredit — Schema Supabase
-- Execute no SQL Editor do Supabase
-- ═══════════════════════════════════════════════════════════════

-- ── Extensões ──────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── Admin (banco central de créditos) ──────────────────────────
CREATE TABLE IF NOT EXISTS admin_config (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  credits       BIGINT  NOT NULL DEFAULT 1000000,  -- Começa com 1M créditos
  total_sold    BIGINT  NOT NULL DEFAULT 0,
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Seed: insere registro admin único
INSERT INTO admin_config (id) VALUES ('00000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

-- ── Clientes (negócios) ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
  id                  UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_name       TEXT NOT NULL,
  business_type       TEXT NOT NULL DEFAULT 'negócio',  -- barbearia, clínica, etc
  email               TEXT UNIQUE NOT NULL,
  password_hash       TEXT NOT NULL,
  document            TEXT,                              -- CPF/CNPJ
  phone               TEXT,
  api_token           TEXT UNIQUE DEFAULT uuid_generate_v4()::TEXT,
  asaas_customer_id   TEXT,
  credits             BIGINT NOT NULL DEFAULT 0,
  total_credits_used  BIGINT NOT NULL DEFAULT 0,
  status              TEXT NOT NULL DEFAULT 'active',   -- active, suspended
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── Configuração do Bot ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bot_configs (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  client_id     UUID REFERENCES clients(id) ON DELETE CASCADE UNIQUE,
  bot_name      TEXT DEFAULT 'Assistente Virtual',
  bot_persona   TEXT,                                    -- Instrução de persona
  services      TEXT[],                                  -- Lista de serviços
  schedule      TEXT,                                    -- Horários
  address       TEXT,
  menus         JSONB DEFAULT '[]',                      -- Menus customizados
  welcome_msg   TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Sessões WhatsApp ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS whatsapp_sessions (
  id          UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  client_id   UUID REFERENCES clients(id) ON DELETE CASCADE UNIQUE,
  status      TEXT NOT NULL DEFAULT 'disconnected',
             -- disconnected | waiting_qr | connected | reconnecting
  phone       TEXT,                                      -- Número conectado
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Transações PIX ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pix_transactions (
  id              UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  client_id       UUID REFERENCES clients(id) ON DELETE CASCADE,
  asaas_id        TEXT UNIQUE NOT NULL,
  amount_brl      NUMERIC(10, 2) NOT NULL,
  base_credits    INT NOT NULL,
  bonus_credits   INT NOT NULL DEFAULT 0,
  total_credits   INT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'pending',       -- pending | paid | expired
  paid_at         TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Histórico de créditos ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS credit_transactions (
  id            UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  client_id     UUID REFERENCES clients(id) ON DELETE CASCADE,
  type          TEXT NOT NULL,   -- debit | credit | bonus | admin_add
  amount        INT NOT NULL,    -- Positivo = crédito, Negativo = débito
  balance_after INT NOT NULL,
  description   TEXT,
  reference_id  TEXT,            -- ID da transação PIX ou mensagem
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Índices ─────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_credit_tx_client ON credit_transactions(client_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pix_tx_client    ON pix_transactions(client_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pix_tx_asaas     ON pix_transactions(asaas_id);

-- ═══════════════════════════════════════════════════════════════
-- FUNÇÕES RPC (operações atômicas — evitam race conditions)
-- ═══════════════════════════════════════════════════════════════

-- ── Debitar créditos (3 por resposta do bot) ────────────────────
CREATE OR REPLACE FUNCTION debit_credits(
  p_client_id   UUID,
  p_amount      INT,
  p_description TEXT
) RETURNS JSON AS $$
DECLARE
  v_balance     INT;
  v_new_balance INT;
BEGIN
  -- Lock na linha do cliente para evitar race condition
  SELECT credits INTO v_balance
  FROM clients
  WHERE id = p_client_id
  FOR UPDATE;

  IF v_balance < p_amount THEN
    RAISE EXCEPTION 'Saldo insuficiente: % créditos disponíveis', v_balance;
  END IF;

  v_new_balance := v_balance - p_amount;

  UPDATE clients SET
    credits            = v_new_balance,
    total_credits_used = total_credits_used + p_amount,
    updated_at         = NOW()
  WHERE id = p_client_id;

  INSERT INTO credit_transactions (client_id, type, amount, balance_after, description)
  VALUES (p_client_id, 'debit', -p_amount, v_new_balance, p_description);

  RETURN json_build_object('new_balance', v_new_balance);
END;
$$ LANGUAGE plpgsql;

-- ── Processar compra PIX confirmada ─────────────────────────────
CREATE OR REPLACE FUNCTION process_credit_purchase(
  p_client_id       UUID,
  p_amount_brl      NUMERIC,
  p_base_credits    INT,
  p_bonus_credits   INT,
  p_transaction_id  TEXT
) RETURNS JSON AS $$
DECLARE
  v_total_credits    INT;
  v_client_new_bal   INT;
  v_admin_new_bal    BIGINT;
BEGIN
  v_total_credits := p_base_credits + p_bonus_credits;

  -- Desconta do banco central admin
  UPDATE admin_config SET
    credits    = credits - v_total_credits,
    total_sold = total_sold + v_total_credits,
    updated_at = NOW()
  WHERE id = '00000000-0000-0000-0000-000000000001'
  RETURNING credits INTO v_admin_new_bal;

  -- Credita no cliente
  UPDATE clients SET
    credits    = credits + v_total_credits,
    updated_at = NOW()
  WHERE id = p_client_id
  RETURNING credits INTO v_client_new_bal;

  -- Registra no histórico
  INSERT INTO credit_transactions (client_id, type, amount, balance_after, description, reference_id)
  VALUES (p_client_id, 'credit', p_base_credits, v_client_new_bal,
          FORMAT('Recarga PIX R$ %s', p_amount_brl), p_transaction_id);

  -- Registra bônus separado (se houver)
  IF p_bonus_credits > 0 THEN
    INSERT INTO credit_transactions (client_id, type, amount, balance_after, description, reference_id)
    VALUES (p_client_id, 'bonus', p_bonus_credits, v_client_new_bal,
            FORMAT('Bônus 10%% — R$ %s', p_amount_brl), p_transaction_id);
  END IF;

  RETURN json_build_object(
    'new_balance',       v_client_new_bal,
    'admin_new_balance', v_admin_new_bal
  );
END;
$$ LANGUAGE plpgsql;

-- ── Admin adiciona créditos manualmente ─────────────────────────
CREATE OR REPLACE FUNCTION admin_add_credits(
  p_client_id   UUID,
  p_amount      INT,
  p_admin_id    UUID,
  p_description TEXT
) RETURNS JSON AS $$
DECLARE
  v_new_balance INT;
BEGIN
  UPDATE clients SET
    credits    = credits + p_amount,
    updated_at = NOW()
  WHERE id = p_client_id
  RETURNING credits INTO v_new_balance;

  UPDATE admin_config SET
    credits    = credits - p_amount,
    updated_at = NOW()
  WHERE id = '00000000-0000-0000-0000-000000000001';

  INSERT INTO credit_transactions (client_id, type, amount, balance_after, description)
  VALUES (p_client_id, 'admin_add', p_amount, v_new_balance, p_description);

  RETURN json_build_object('new_balance', v_new_balance);
END;
$$ LANGUAGE plpgsql;

-- ── RLS (Row Level Security) — Habilite se usar Supabase Auth ───
-- ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE bot_configs ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE credit_transactions ENABLE ROW LEVEL SECURITY;
