# ⚡ BotCredit — Plataforma Multi-Tenant de Chatbot WhatsApp

Bot WhatsApp com IA (Claude) para múltiplos negócios, com sistema de créditos e pagamento PIX automático.

---

## 🏗 Arquitetura

```
┌─────────────────────────────────────────────────────────────┐
│                     SERVIDOR CENTRAL (Node.js)               │
│                                                               │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────┐ │
│  │  SessionMgr  │   │  MsgHandler  │   │  CreditService   │ │
│  │  (Baileys)   │──▶│  (Claude AI) │──▶│  (3cr/resposta)  │ │
│  └──────────────┘   └──────────────┘   └──────────────────┘ │
│         │                                        │           │
│  ┌──────▼──────────────────────────────────────▼─────────┐  │
│  │              Supabase (PostgreSQL)                      │  │
│  │  clients │ bot_configs │ pix_transactions │ credits     │  │
│  └────────────────────────────────────────────────────────┘  │
│                           │                                   │
│  ┌────────────────────────▼───────────────────────────────┐  │
│  │       WebSocket (Socket.IO) → Frontend React            │  │
│  │   QR Code • status conexão • créditos em tempo real     │  │
│  └────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
         │                                    │
    ┌────▼─────┐                     ┌────────▼──────┐
    │ WhatsApp │                     │  Asaas (PIX)  │
    │ (Baileys)│                     │  Webhook →    │
    └──────────┘                     │  confirma pag │
                                     └───────────────┘
```

### Fluxo de uma mensagem:
```
1. Usuário manda mensagem no WhatsApp
2. Baileys recebe → messageHandler.handle()
3. Verifica créditos (≥ 3) → se insuficiente, avisa e para
4. Checa se é comando de menu → resposta instantânea sem IA
5. Se não for menu → chama Claude API com contexto + persona
6. Envia resposta no WhatsApp
7. Debita 3 créditos (atômico no Supabase)
8. Notifica painel via WebSocket em tempo real
```

### Fluxo de compra PIX:
```
1. Cliente escolhe valor no painel
2. POST /api/pix/create → gera QR Code no Asaas
3. Cliente paga com PIX
4. Asaas chama webhook POST /api/pix/webhook
5. process_credit_purchase() (SQL atômico):
   - Desconta do banco central admin
   - Credita na conta do cliente (+10% se ≥ R$25)
6. WebSocket notifica painel em tempo real
```

---

## 🚀 Setup

### 1. Pré-requisitos
- Node.js 18+
- Conta Supabase (gratuita): https://supabase.com
- Conta Asaas (sandbox gratuito): https://asaas.com
- API Key Anthropic: https://console.anthropic.com

### 2. Instalação
```bash
git clone <repo>
cd botcredit-server
npm install
cp .env.example .env
# Preencha as variáveis no .env
```

### 3. Banco de dados
1. Acesse seu projeto no Supabase
2. Vá em **SQL Editor**
3. Cole e execute o conteúdo de `database/schema.sql`

### 4. Configurar Asaas
1. Crie conta em https://asaas.com (sandbox)
2. Copie sua API Key para `ASAAS_API_KEY`
3. Configure o webhook:
   - URL: `https://seu-servidor.com/api/pix/webhook`
   - Evento: `PAYMENT_RECEIVED`
   - Copie o token para `ASAAS_WEBHOOK_TOKEN`

### 5. Rodar
```bash
npm run dev   # Desenvolvimento
npm start     # Produção
```

---

## 📁 Estrutura de arquivos

```
src/
├── server.js                    # Entry point, Express + Socket.IO
├── whatsapp/
│   ├── sessionManager.js        # Gerencia N sessões Baileys
│   ├── messageHandler.js        # Processa mensagens + Claude AI
│   └── menuService.js           # Menus interativos por tipo de negócio
├── services/
│   └── creditService.js         # Lógica de créditos (débito, compra, bônus)
├── routes/
│   ├── auth.js                  # Login/registro de clientes
│   ├── client.js                # Rotas do painel cliente
│   ├── admin.js                 # Rotas do painel admin
│   └── pix.js                   # Criar cobrança + webhook Asaas
├── middleware/
│   └── auth.js                  # JWT middleware
└── database/
    └── supabase.js              # Queries centralizadas
database/
└── schema.sql                   # Tabelas + funções RPC atômicas
```

---

## ⚙️ Sistema de créditos

| Ação | Créditos |
|------|----------|
| Resposta do bot (IA ou menu) | -3 |
| R$ 1,00 pago | +10 |
| Bônus compra ≥ R$ 25 | +10% |

**Exemplo:** Cliente paga R$ 50  
→ 500 créditos base + 50 bônus = **550 créditos**  
→ ≈ 183 respostas do bot

### Banco central Admin
- Começa com 1.000.000 créditos
- Toda compra de cliente desconta do admin
- Admin pode adicionar créditos manualmente pelo painel

---

## 🚀 Deploy (produção)

### Opção 1 — Railway (recomendado)
```bash
railway login
railway init
railway up
```
Configure as variáveis de ambiente no painel do Railway.

### Opção 2 — VPS (Ubuntu)
```bash
# Instala PM2
npm install -g pm2

# Inicia com PM2 (mantém ativo após restart)
pm2 start src/server.js --name botcredit
pm2 save
pm2 startup
```

> ⚠️ **Importante:** O Baileys salva arquivos de sessão localmente em `./sessions/`.
> Em produção use um volume persistente ou sincronize com S3/Supabase Storage.

---

## 🔌 Frontend — Conectar QR Code

```javascript
import { io } from "socket.io-client";

const socket = io("https://seu-servidor.com");

// Solicita início de sessão
socket.emit("start-session", { clientId: "uuid-do-cliente", token: "api-token" });

// Recebe QR Code para exibir
socket.on("qr-code", ({ qr }) => {
  // Use a biblioteca 'qrcode' para renderizar
  QRCode.toCanvas(canvasElement, qr);
});

// Atualização de status
socket.on("session-status", ({ status, phone }) => {
  console.log(`Status: ${status} | Número: ${phone}`);
});

// Créditos atualizados em tempo real
socket.on("credits-added", ({ totalCredits, newBalance }) => {
  console.log(`+${totalCredits} créditos! Saldo: ${newBalance}`);
});
```
