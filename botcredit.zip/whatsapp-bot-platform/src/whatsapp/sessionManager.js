/**
 * SessionManager — Coração do sistema multi-tenant
 * Gerencia N sessões Baileys simultâneas, uma por cliente
 */

import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  isJidBroadcast,
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import pino from "pino";
import path from "path";
import fs from "fs";
import { messageHandler } from "./messageHandler.js";
import { db } from "../database/supabase.js";

const SESSIONS_DIR = process.env.SESSIONS_DIR || "./sessions";
const logger = pino({ level: "silent" }); // Silencia logs verbosos do Baileys

class SessionManager {
  constructor() {
    /** @type {Map<string, import("@whiskeysockets/baileys").WASocket>} */
    this.sessions = new Map();

    /** @type {Map<string, ReturnType<typeof setTimeout>>} */
    this.reconnectTimers = new Map();
  }

  // ── Iniciar ou reconectar sessão ─────────────────────────────────────────
  async startSession(clientId) {
    if (this.sessions.has(clientId)) {
      console.log(`[Session] ${clientId} já está ativa`);
      return;
    }

    console.log(`[Session] Iniciando sessão para: ${clientId}`);

    // Diretório de auth por cliente — mantém sessão mesmo após restart
    const authDir = path.join(SESSIONS_DIR, clientId);
    fs.mkdirSync(authDir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(authDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      version,
      logger,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, logger),
      },
      printQRInTerminal: false,      // QR vai pro frontend via WebSocket
      generateHighQualityLinkPreview: false,
      getMessage: async (key) => ({ conversation: "" }),
    });

    this.sessions.set(clientId, sock);

    // ── Eventos da conexão ──────────────────────────────────────────────
    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      await this._handleConnectionUpdate(clientId, update, sock);
    });

    sock.ev.on("messages.upsert", async ({ messages, type }) => {
      if (type !== "notify") return;

      for (const msg of messages) {
        // Ignora mensagens do próprio bot, broadcasts e status
        if (msg.key.fromMe) continue;
        if (isJidBroadcast(msg.key.remoteJid)) continue;
        if (msg.key.remoteJid === "status@broadcast") continue;

        await messageHandler.handle(clientId, sock, msg);
      }
    });
  }

  // ── Parar sessão ────────────────────────────────────────────────────────
  async stopSession(clientId) {
    const sock = this.sessions.get(clientId);
    if (!sock) return;

    try {
      await sock.logout();
    } catch {}

    this.sessions.delete(clientId);
    this._clearReconnectTimer(clientId);

    // Limpa arquivos de autenticação
    const authDir = path.join(SESSIONS_DIR, clientId);
    fs.rmSync(authDir, { recursive: true, force: true });

    await db.updateSessionStatus(clientId, "disconnected");
    global.io?.to(`client:${clientId}`).emit("session-status", {
      clientId,
      status: "disconnected",
      phone: null,
    });

    console.log(`[Session] ${clientId} desconectada e limpa`);
  }

  // ── Handler de atualizações de conexão ─────────────────────────────────
  async _handleConnectionUpdate(clientId, update, sock) {
    const { connection, lastDisconnect, qr } = update;

    // QR Code — envia para o frontend via WebSocket
    if (qr) {
      console.log(`[Session] QR gerado para ${clientId}`);
      global.io?.to(`client:${clientId}`).emit("qr-code", { clientId, qr });
      await db.updateSessionStatus(clientId, "waiting_qr");
    }

    if (connection === "open") {
      const phone = sock.user?.id?.split(":")[0] || "desconhecido";
      console.log(`[Session] ✅ ${clientId} conectado — ${phone}`);

      global.io?.to(`client:${clientId}`).emit("session-status", {
        clientId,
        status: "connected",
        phone,
      });

      await db.updateSessionStatus(clientId, "connected", phone);
      this._clearReconnectTimer(clientId);
    }

    if (connection === "close") {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = reason !== DisconnectReason.loggedOut;

      console.log(`[Session] ❌ ${clientId} desconectado. Motivo: ${reason} | Reconectar: ${shouldReconnect}`);

      this.sessions.delete(clientId);

      global.io?.to(`client:${clientId}`).emit("session-status", {
        clientId,
        status: shouldReconnect ? "reconnecting" : "disconnected",
      });

      await db.updateSessionStatus(clientId, shouldReconnect ? "reconnecting" : "disconnected");

      if (shouldReconnect) {
        this._scheduleReconnect(clientId);
      } else {
        // Sessão encerrada pelo usuário — limpa auth
        const authDir = path.join(SESSIONS_DIR, clientId);
        fs.rmSync(authDir, { recursive: true, force: true });
      }
    }
  }

  // ── Reconexão com backoff exponencial ───────────────────────────────────
  _scheduleReconnect(clientId, attempt = 1) {
    const delay = Math.min(1000 * 2 ** attempt, 30000); // Máx 30s
    console.log(`[Session] Reconectando ${clientId} em ${delay}ms (tentativa ${attempt})`);

    const timer = setTimeout(async () => {
      await this.startSession(clientId).catch(console.error);
    }, delay);

    this.reconnectTimers.set(clientId, { timer, attempt });
  }

  _clearReconnectTimer(clientId) {
    const entry = this.reconnectTimers.get(clientId);
    if (entry) {
      clearTimeout(entry.timer);
      this.reconnectTimers.delete(clientId);
    }
  }

  // ── Utilitários ─────────────────────────────────────────────────────────
  getSession(clientId) {
    return this.sessions.get(clientId) || null;
  }

  isConnected(clientId) {
    return this.sessions.has(clientId);
  }

  getAllSessions() {
    return [...this.sessions.keys()];
  }
}

export const sessionManager = new SessionManager();
