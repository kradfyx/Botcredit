/**
 * MessageHandler — Processa cada mensagem recebida no WhatsApp
 * Fluxo: receber msg → checar créditos → IA ou menu → debitar 3 créditos → responder
 */

import Anthropic from "@anthropic-ai/sdk";
import { db } from "../database/supabase.js";
import { creditService } from "../services/creditService.js";
import { menuService } from "./menuService.js";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Histórico de conversas em memória (por clientId + número do usuário)
// Em produção considere Redis para múltiplos workers
const conversationHistory = new Map();

// Controle de modo "atendimento humano" ativo
const humanHandoffActive = new Map(); // `${clientId}:${userJid}` → true/false

class MessageHandler {

  async handle(clientId, sock, msg) {
    const jid = msg.key.remoteJid;
    const userPhone = jid.replace("@s.whatsapp.net", "");
    const text = this._extractText(msg);

    if (!text || text.trim() === "") return;

    console.log(`[MSG] ${clientId} ← ${userPhone}: ${text.substring(0, 60)}`);

    try {
      // ── 1. Verificar se está em modo atendimento humano ─────────────
      const handoffKey = `${clientId}:${jid}`;
      if (humanHandoffActive.get(handoffKey)) {
        // Em modo humano, não responde automaticamente
        // Só notifica o painel que chegou mensagem nova
        global.io?.to(`client:${clientId}`).emit("human-message", {
          from: userPhone, text, timestamp: Date.now(),
        });
        return;
      }

      // ── 2. Checar créditos disponíveis ──────────────────────────────
      const hasCredits = await creditService.hasEnoughCredits(clientId, 3);
      if (!hasCredits) {
        await sock.sendMessage(jid, {
          text: "⚠️ Desculpe, o atendimento automático está temporariamente indisponível. Por favor, entre em contato diretamente conosco.",
        });
        // Alerta o painel
        global.io?.to(`client:${clientId}`).emit("credits-empty", { clientId });
        return;
      }

      // ── 3. Detectar comandos de menu ────────────────────────────────
      const menuResponse = await menuService.checkMenu(clientId, jid, text);
      if (menuResponse) {
        if (menuResponse.humanHandoff) {
          humanHandoffActive.set(handoffKey, true);
          global.io?.to(`client:${clientId}`).emit("handoff-requested", {
            from: userPhone, jid, timestamp: Date.now(),
          });
        }
        await sock.sendMessage(jid, { text: menuResponse.text });
        await creditService.debitCredits(clientId, 3, `menu:${userPhone}`);
        return;
      }

      // ── 4. Gerar resposta com Claude AI ─────────────────────────────
      const config = await db.getClientBotConfig(clientId);
      const reply = await this._generateAIResponse(clientId, jid, text, config);

      // ── 5. Enviar resposta ──────────────────────────────────────────
      await sock.sendMessage(jid, { text: reply });

      // ── 6. Debitar 3 créditos ───────────────────────────────────────
      await creditService.debitCredits(clientId, 3, `ai:${userPhone}`);

      // ── 7. Notificar painel em tempo real ───────────────────────────
      const balance = await creditService.getBalance(clientId);
      global.io?.to(`client:${clientId}`).emit("message-sent", {
        from: userPhone, userText: text, botReply: reply,
        creditsUsed: 3, balance, timestamp: Date.now(),
      });

    } catch (err) {
      console.error(`[MSG] Erro ao processar mensagem de ${clientId}:`, err.message);
    }
  }

  // ── Gera resposta com Claude mantendo histórico ─────────────────────────
  async _generateAIResponse(clientId, jid, userText, config) {
    const histKey = `${clientId}:${jid}`;

    // Inicializa ou recupera histórico (máx 20 mensagens para economizar tokens)
    if (!conversationHistory.has(histKey)) {
      conversationHistory.set(histKey, []);
    }
    const history = conversationHistory.get(histKey);

    // Adiciona mensagem do usuário ao histórico
    history.push({ role: "user", content: userText });

    // Monta system prompt com a persona do cliente
    const systemPrompt = this._buildSystemPrompt(config);

    try {
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1024,
        system: systemPrompt,
        messages: history.slice(-20), // Janela de contexto: últimas 20 mensagens
      });

      const reply = response.content[0].text;

      // Adiciona resposta ao histórico
      history.push({ role: "assistant", content: reply });

      // Limita histórico a 40 mensagens (20 pares)
      if (history.length > 40) history.splice(0, 2);

      return reply;
    } catch (err) {
      console.error("[AI] Erro ao chamar Claude:", err.message);
      return "Desculpe, ocorreu um erro. Por favor, tente novamente em instantes.";
    }
  }

  // ── Monta o system prompt com as configs do cliente ─────────────────────
  _buildSystemPrompt(config) {
    const businessType = config?.business_type || "negócio";
    const businessName = config?.business_name || "nossa empresa";
    const persona      = config?.bot_persona || "";
    const services     = config?.services?.join(", ") || "";
    const schedule     = config?.schedule || "";
    const address      = config?.address || "";

    return `Você é um assistente virtual de WhatsApp do(a) ${businessType} "${businessName}".

${persona ? `Sua personalidade: ${persona}` : ""}

${services ? `Serviços oferecidos: ${services}` : ""}
${schedule ? `Horário de funcionamento: ${schedule}` : ""}
${address  ? `Endereço: ${address}` : ""}

REGRAS IMPORTANTES:
- Responda SEMPRE em português brasileiro
- Seja cordial, objetivo e profissional
- Mensagens curtas e diretas (WhatsApp, não e-mail)
- Se não souber algo, peça para o cliente aguardar ou falar com um humano
- Para agendar, colete: nome, serviço desejado e horário preferido
- Nunca invente informações sobre preços ou disponibilidade que não foram fornecidas
- Se o cliente digitar "menu" ou "ajuda", mostre as opções disponíveis
- Se o cliente quiser falar com humano, diga que vai transferir o atendimento`.trim();
  }

  // ── Extrai texto da mensagem (suporta tipos diferentes) ─────────────────
  _extractText(msg) {
    const m = msg.message;
    if (!m) return "";
    return (
      m.conversation ||
      m.extendedTextMessage?.text ||
      m.imageMessage?.caption ||
      m.videoMessage?.caption ||
      m.buttonsResponseMessage?.selectedDisplayText ||
      m.listResponseMessage?.title ||
      ""
    );
  }

  // ── Retomar atendimento humano → bot ────────────────────────────────────
  resumeBot(clientId, jid) {
    const handoffKey = `${clientId}:${jid}`;
    humanHandoffActive.delete(handoffKey);
    console.log(`[MSG] Bot reativado para ${clientId}:${jid}`);
  }

  // ── Limpar histórico de conversa ────────────────────────────────────────
  clearHistory(clientId, jid) {
    conversationHistory.delete(`${clientId}:${jid}`);
  }
}

export const messageHandler = new MessageHandler();
