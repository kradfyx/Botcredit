/**
 * MenuService — Menus interativos configuráveis por cliente
 * Detecta palavras-chave e retorna respostas prontas sem usar IA (sem gastar créditos extras)
 */

import { db } from "../database/supabase.js";

// Estado do menu por usuário
const userMenuState = new Map(); // `${clientId}:${jid}` → estado atual

class MenuService {
  /**
   * Verifica se a mensagem é um comando de menu
   * Retorna { text, humanHandoff? } ou null se não for menu
   */
  async checkMenu(clientId, jid, text) {
    const key = `${clientId}:${jid}`;
    const normalized = text.trim().toLowerCase();
    const config = await db.getClientBotConfig(clientId);

    // ── Comandos globais (sempre funcionam) ────────────────────────────
    if (["menu", "ajuda", "oi", "olá", "ola", "início", "inicio", "1"].includes(normalized)) {
      userMenuState.delete(key); // Reseta estado
      return { text: this._buildMainMenu(config) };
    }

    if (["humano", "atendente", "pessoa", "0"].includes(normalized)) {
      return {
        text: `👤 *Transferindo para atendimento humano...*\n\nUm de nossos atendentes entrará em contato em breve.\n\nDigite *menu* para voltar ao atendimento automático.`,
        humanHandoff: true,
      };
    }

    // ── Menus personalizados do cliente ────────────────────────────────
    const customMenus = config?.menus || this._getDefaultMenus(config);

    for (const menu of customMenus) {
      if (menu.triggers.includes(normalized)) {
        userMenuState.set(key, menu.id);
        return { text: menu.response };
      }
    }

    // Se está em estado de menu e digita número, tenta submenu
    const currentState = userMenuState.get(key);
    if (currentState) {
      const parentMenu = customMenus.find(m => m.id === currentState);
      if (parentMenu?.submenus) {
        const sub = parentMenu.submenus.find(s => s.trigger === normalized);
        if (sub) return { text: sub.response };
      }
    }

    return null; // Não é menu — vai para IA
  }

  // ── Monta o menu principal ─────────────────────────────────────────────
  _buildMainMenu(config) {
    const name    = config?.business_name || "nossa empresa";
    const type    = config?.business_type || "negócio";
    const menus   = config?.menus || this._getDefaultMenus(config);
    const options = menus.map((m, i) => `*${i + 1}* — ${m.label}`).join("\n");

    return `👋 Olá! Bem-vindo(a) ao(à) *${name}*!\n\nComo posso te ajudar?\n\n${options}\n\n*0* — 👤 Falar com atendente\n\n_Digite o número ou a opção desejada_`;
  }

  // ── Menus padrão por tipo de negócio ──────────────────────────────────
  _getDefaultMenus(config) {
    const type = config?.business_type?.toLowerCase() || "";

    const defaults = {
      barbearia: [
        {
          id: "agendar", label: "✂️ Agendar horário",
          triggers: ["agendar", "agendamento", "horário", "horario", "marcar", "2"],
          response: "📅 *Agendamento*\n\nPara agendar, me informe:\n\n1️⃣ Seu nome\n2️⃣ Serviço desejado\n3️⃣ Dia e horário de preferência\n\nVou verificar a disponibilidade para você! 😊",
        },
        {
          id: "servicos", label: "💈 Serviços e preços",
          triggers: ["serviços", "servicos", "preço", "preco", "valor", "tabela", "3"],
          response: "💈 *Nossos Serviços*\n\n✂️ Corte — R$ 35\n🪒 Barba — R$ 25\n✂️🪒 Corte + Barba — R$ 55\n💆 Hidratação — R$ 40\n\n_Preços podem variar. Consulte-nos!_",
        },
        {
          id: "horarios", label: "🕐 Horários de funcionamento",
          triggers: ["horários", "horarios", "funciona", "abre", "fecha", "4"],
          response: "🕐 *Horários de Funcionamento*\n\n📅 Seg a Sex: 09h às 19h\n📅 Sábado: 08h às 18h\n❌ Domingo: Fechado",
        },
        {
          id: "local", label: "📍 Localização",
          triggers: ["localização", "localizacao", "endereço", "endereco", "onde", "5"],
          response: `📍 *Nossa Localização*\n\n${config?.address || "Entre em contato para obter o endereço."}\n\n_Clique no endereço para abrir no mapa._`,
        },
      ],
      clínica: [
        {
          id: "consulta", label: "🩺 Agendar consulta",
          triggers: ["consulta", "agendar", "médico", "medico", "marcar", "2"],
          response: "🩺 *Agendamento de Consulta*\n\nPara agendar, informe:\n\n1️⃣ Seu nome completo\n2️⃣ Especialidade desejada\n3️⃣ Data e turno (manhã/tarde)\n4️⃣ Plano de saúde (ou particular)\n\nRetornaremos em breve! 😊",
        },
        {
          id: "especialidades", label: "🏥 Especialidades",
          triggers: ["especialidades", "médicos", "medicos", "especialista", "3"],
          response: "🏥 *Nossas Especialidades*\n\n• Clínica Geral\n• Cardiologia\n• Dermatologia\n• Ortopedia\n• Pediatria\n\n_Para mais informações, fale com nossa equipe._",
        },
        {
          id: "convenios", label: "💳 Convênios aceitos",
          triggers: ["convênio", "convenio", "plano", "saúde", "saude", "4"],
          response: "💳 *Convênios Aceitos*\n\n✅ Unimed\n✅ Bradesco Saúde\n✅ Amil\n✅ SulAmérica\n✅ Particular\n\n_Consulte sua cobertura antes de agendar._",
        },
      ],
      salão: [
        {
          id: "agendar", label: "💅 Agendar horário",
          triggers: ["agendar", "agendamento", "horário", "horario", "marcar", "2"],
          response: "💅 *Agendamento*\n\nMe informe:\n\n1️⃣ Seu nome\n2️⃣ Serviço desejado\n3️⃣ Dia e horário preferido\n\nVou verificar para você! ✨",
        },
        {
          id: "servicos", label: "✨ Serviços e preços",
          triggers: ["serviços", "servicos", "preço", "preco", "valor", "3"],
          response: "✨ *Nossos Serviços*\n\n💇 Corte feminino — R$ 60\n🎨 Coloração — a partir de R$ 120\n💅 Manicure — R$ 35\n💅 Pedicure — R$ 40\n✨ Escova — R$ 50\n\n_Pacotes especiais disponíveis!_",
        },
      ],
    };

    return defaults[type] || defaults.barbearia;
  }
}

export const menuService = new MenuService();
