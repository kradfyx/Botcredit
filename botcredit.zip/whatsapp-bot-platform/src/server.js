/**
 * BotCredit — Servidor Central Multi-Tenant
 * WhatsApp via Baileys + Claude AI + Sistema de Créditos
 */

import express from "express";
import { createServer } from "http";
import { Server as SocketIO } from "socket.io";
import cors from "cors";
import dotenv from "dotenv";
import { sessionManager } from "./whatsapp/sessionManager.js";
import { authRouter } from "./routes/auth.js";
import { clientRouter } from "./routes/client.js";
import { adminRouter } from "./routes/admin.js";
import { pixRouter } from "./routes/pix.js";
import { db } from "./database/supabase.js";

dotenv.config();

const app = express();
const httpServer = createServer(app);

// ── WebSocket para QR Code e status em tempo real ──────────────────────────
const io = new SocketIO(httpServer, {
  cors: { origin: process.env.FRONTEND_URL || "http://localhost:3000", credentials: true },
});

// Torna o io acessível globalmente para o sessionManager emitir eventos
global.io = io;

// ── Middlewares ────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000", credentials: true }));
app.use(express.json());

// ── Rotas ─────────────────────────────────────────────────────────────────
app.use("/api/auth",   authRouter);
app.use("/api/client", clientRouter);
app.use("/api/admin",  adminRouter);
app.use("/api/pix",    pixRouter);       // Webhook PIX + criação de cobranças

// ── WebSocket ─────────────────────────────────────────────────────────────
io.on("connection", (socket) => {
  console.log(`[WS] Cliente conectado: ${socket.id}`);

  // Cliente solicita conexão WhatsApp — recebe QR Code
  socket.on("start-session", async ({ clientId, token }) => {
    try {
      const valid = await db.validateClientToken(clientId, token);
      if (!valid) return socket.emit("error", { msg: "Token inválido" });

      socket.join(`client:${clientId}`);  // Sala exclusiva do cliente
      await sessionManager.startSession(clientId);
    } catch (err) {
      socket.emit("error", { msg: err.message });
    }
  });

  // Cliente solicita desconectar WhatsApp
  socket.on("stop-session", async ({ clientId, token }) => {
    const valid = await db.validateClientToken(clientId, token);
    if (!valid) return socket.emit("error", { msg: "Token inválido" });
    await sessionManager.stopSession(clientId);
  });

  socket.on("disconnect", () => {
    console.log(`[WS] Cliente desconectado: ${socket.id}`);
  });
});

// ── Start ─────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, async () => {
  console.log(`\n🚀 BotCredit rodando na porta ${PORT}`);

  // Re-conecta sessões ativas após restart do servidor
  const activeSessions = await db.getActiveSessions();
  console.log(`📱 Reconectando ${activeSessions.length} sessões ativas...`);
  for (const session of activeSessions) {
    await sessionManager.startSession(session.client_id).catch(console.error);
  }
});

export { io };
