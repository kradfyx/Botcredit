/**
 * Database — Wrapper Supabase
 * Centraliza todas as queries do sistema
 */

import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY  // Service key — só no backend!
);

class Database {
  get client() {
    return supabase;
  }

  // ── Clientes ──────────────────────────────────────────────────────────
  async getClient(clientId) {
    const { data, error } = await supabase
      .from("clients")
      .select("*")
      .eq("id", clientId)
      .single();
    if (error) throw new Error(error.message);
    return data;
  }

  async updateClient(clientId, updates) {
    const { error } = await supabase
      .from("clients")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", clientId);
    if (error) throw new Error(error.message);
  }

  async validateClientToken(clientId, token) {
    const { data } = await supabase
      .from("clients")
      .select("api_token")
      .eq("id", clientId)
      .single();
    return data?.api_token === token;
  }

  // ── Bot Config ────────────────────────────────────────────────────────
  async getClientBotConfig(clientId) {
    const { data } = await supabase
      .from("bot_configs")
      .select("*")
      .eq("client_id", clientId)
      .single();
    return data;
  }

  async upsertBotConfig(clientId, config) {
    const { error } = await supabase
      .from("bot_configs")
      .upsert({ client_id: clientId, ...config, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
  }

  // ── Sessões WhatsApp ──────────────────────────────────────────────────
  async getActiveSessions() {
    const { data } = await supabase
      .from("whatsapp_sessions")
      .select("client_id")
      .in("status", ["connected", "reconnecting"]);
    return data || [];
  }

  async updateSessionStatus(clientId, status, phone = null) {
    await supabase.from("whatsapp_sessions").upsert({
      client_id:  clientId,
      status,
      phone:      phone || undefined,
      updated_at: new Date().toISOString(),
    });
  }

  // ── Transações PIX ────────────────────────────────────────────────────
  async createPendingTransaction(tx) {
    const { error } = await supabase.from("pix_transactions").insert(tx);
    if (error) throw new Error(error.message);
  }

  async getPendingTransaction(asaasId) {
    const { data } = await supabase
      .from("pix_transactions")
      .select("*")
      .eq("asaas_id", asaasId)
      .single();
    return data;
  }

  async updateTransactionStatus(asaasId, status) {
    await supabase
      .from("pix_transactions")
      .update({ status, paid_at: new Date().toISOString() })
      .eq("asaas_id", asaasId);
  }
}

export const db = new Database();
