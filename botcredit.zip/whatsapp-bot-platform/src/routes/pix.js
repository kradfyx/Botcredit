/**
 * PIX Router — Integração com Asaas para cobranças PIX
 * POST /api/pix/create     → Gera QR Code PIX
 * POST /api/pix/webhook    → Recebe confirmação de pagamento (chamado pelo Asaas)
 */

import express from "express";
import axios from "axios";
import crypto from "crypto";
import { creditService } from "../services/creditService.js";
import { db } from "../database/supabase.js";
import { authMiddleware } from "../middleware/auth.js";

export const pixRouter = express.Router();

const ASAAS_API_KEY = process.env.ASAAS_API_KEY;
const ASAAS_BASE    = process.env.ASAAS_ENV === "production"
  ? "https://api.asaas.com/v3"
  : "https://sandbox.asaas.com/api/v3";

// ── Criar cobrança PIX ──────────────────────────────────────────────────────
pixRouter.post("/create", authMiddleware, async (req, res) => {
  try {
    const { clientId } = req.user;
    const { amountBRL } = req.body;

    if (!amountBRL || amountBRL < 10) {
      return res.status(400).json({ error: "Valor mínimo: R$ 10,00" });
    }

    // Busca ou cria cliente no Asaas
    const clientData = await db.getClient(clientId);
    let asaasCustomerId = clientData.asaas_customer_id;

    if (!asaasCustomerId) {
      asaasCustomerId = await createAsaasCustomer(clientData);
      await db.updateClient(clientId, { asaas_customer_id: asaasCustomerId });
    }

    // Calcula créditos antecipadamente para mostrar no front
    const purchase = creditService.calculatePurchase(amountBRL);

    // Cria cobrança PIX no Asaas
    const charge = await axios.post(
      `${ASAAS_BASE}/payments`,
      {
        customer: asaasCustomerId,
        billingType: "PIX",
        value: amountBRL,
        dueDate: new Date(Date.now() + 30 * 60 * 1000).toISOString().split("T")[0], // 30 min
        description: `BotCredit — Recarga de ${purchase.totalCredits} créditos`,
        externalReference: `${clientId}:${Date.now()}`, // Para identificar no webhook
      },
      { headers: { access_token: ASAAS_API_KEY } }
    );

    // Busca QR Code PIX
    const pixData = await axios.get(
      `${ASAAS_BASE}/payments/${charge.data.id}/pixQrCode`,
      { headers: { access_token: ASAAS_API_KEY } }
    );

    // Salva transação pendente no banco
    await db.createPendingTransaction({
      client_id:      clientId,
      asaas_id:       charge.data.id,
      amount_brl:     amountBRL,
      base_credits:   purchase.baseCredits,
      bonus_credits:  purchase.bonusCredits,
      total_credits:  purchase.totalCredits,
      status:         "pending",
    });

    return res.json({
      chargeId:      charge.data.id,
      qrCodeImage:   pixData.data.encodedImage,   // Base64 da imagem do QR Code
      qrCodePayload: pixData.data.payload,         // Código copia e cola
      expiresAt:     charge.data.dueDate,
      purchase,
    });

  } catch (err) {
    console.error("[PIX] Erro ao criar cobrança:", err.response?.data || err.message);
    return res.status(500).json({ error: "Erro ao gerar cobrança PIX" });
  }
});

// ── Webhook Asaas — confirmação de pagamento ───────────────────────────────
pixRouter.post("/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    // Valida assinatura do webhook (segurança)
    const signature = req.headers["asaas-signature"];
    if (!validateWebhookSignature(req.body, signature)) {
      console.warn("[Webhook] Assinatura inválida!");
      return res.status(401).json({ error: "Assinatura inválida" });
    }

    const event = JSON.parse(req.body.toString());
    console.log(`[Webhook] Evento recebido: ${event.event}`);

    // Processa apenas pagamentos confirmados
    if (event.event === "PAYMENT_RECEIVED" || event.event === "PAYMENT_CONFIRMED") {
      const payment = event.payment;
      const chargeId = payment.id;

      // Busca transação pendente
      const transaction = await db.getPendingTransaction(chargeId);
      if (!transaction) {
        console.warn(`[Webhook] Transação ${chargeId} não encontrada`);
        return res.status(200).json({ received: true });
      }

      if (transaction.status === "paid") {
        // Já processado (webhook duplicado)
        return res.status(200).json({ received: true });
      }

      // Credita os créditos na conta do cliente
      await creditService.creditPurchase(
        transaction.client_id,
        transaction.amount_brl,
        chargeId
      );

      // Marca transação como paga
      await db.updateTransactionStatus(chargeId, "paid");

      console.log(`[Webhook] ✅ Pagamento ${chargeId} processado para ${transaction.client_id}`);
    }

    return res.status(200).json({ received: true });

  } catch (err) {
    console.error("[Webhook] Erro:", err.message);
    return res.status(500).json({ error: "Erro interno" });
  }
});

// ── Utilitários ────────────────────────────────────────────────────────────
async function createAsaasCustomer(clientData) {
  const response = await axios.post(
    `${ASAAS_BASE}/customers`,
    {
      name: clientData.business_name,
      email: clientData.email,
      cpfCnpj: clientData.document || undefined,
    },
    { headers: { access_token: ASAAS_API_KEY } }
  );
  return response.data.id;
}

function validateWebhookSignature(rawBody, signature) {
  if (!process.env.ASAAS_WEBHOOK_TOKEN) return true; // Skip em dev
  const expected = crypto
    .createHmac("sha256", process.env.ASAAS_WEBHOOK_TOKEN)
    .update(rawBody)
    .digest("hex");
  return signature === expected;
}
