/**
 * CreditService — Gerencia todo o ciclo de créditos
 * Regras:
 *  - Cada resposta consome 3 créditos do cliente
 *  - Admin tem banco central; cliente compra = desconta do admin + credita no cliente
 *  - Compras >= R$ 25 ganham 10% de bônus automático
 */

import { db } from "../database/supabase.js";

const CREDITS_PER_RESPONSE = 3;
const BONUS_THRESHOLD      = 25;   // R$ mínimo para ganhar bônus
const BONUS_PERCENTAGE     = 0.10; // 10%
const CREDITS_PER_REAL     = 10;   // R$ 1 = 10 créditos

class CreditService {

  // ── Verificar saldo ────────────────────────────────────────────────────
  async getBalance(clientId) {
    const { data, error } = await db.client
      .from("clients")
      .select("credits")
      .eq("id", clientId)
      .single();

    if (error) throw new Error(`Erro ao buscar saldo: ${error.message}`);
    return data.credits;
  }

  async hasEnoughCredits(clientId, amount = CREDITS_PER_RESPONSE) {
    const balance = await this.getBalance(clientId);
    return balance >= amount;
  }

  // ── Debitar créditos (por resposta do bot) ─────────────────────────────
  async debitCredits(clientId, amount = CREDITS_PER_RESPONSE, description = "bot_response") {
    // Usa RPC do Supabase para operação atômica (evita race condition)
    const { data, error } = await db.client.rpc("debit_credits", {
      p_client_id:   clientId,
      p_amount:      amount,
      p_description: description,
    });

    if (error) throw new Error(`Erro ao debitar créditos: ${error.message}`);

    // Alerta créditos baixos
    if (data.new_balance <= 30) {
      global.io?.to(`client:${clientId}`).emit("credits-low", {
        clientId,
        balance: data.new_balance,
        message: `⚠️ Atenção: apenas ${data.new_balance} créditos restantes!`,
      });

      // Alerta admin também
      global.io?.to("admin").emit("client-credits-low", {
        clientId,
        balance: data.new_balance,
      });
    }

    return data.new_balance;
  }

  // ── Calcular créditos de uma compra (com bônus) ────────────────────────
  calculatePurchase(amountBRL) {
    const baseCredits  = Math.floor(amountBRL * CREDITS_PER_REAL);
    const hasBonus     = amountBRL >= BONUS_THRESHOLD;
    const bonusCredits = hasBonus ? Math.floor(baseCredits * BONUS_PERCENTAGE) : 0;
    const totalCredits = baseCredits + bonusCredits;

    return { baseCredits, bonusCredits, totalCredits, hasBonus };
  }

  // ── Creditar compra confirmada ─────────────────────────────────────────
  // Chamado pelo webhook PIX após confirmação do pagamento
  async creditPurchase(clientId, amountBRL, transactionId) {
    const { baseCredits, bonusCredits, totalCredits } = this.calculatePurchase(amountBRL);

    // Transação atômica: desconta do admin + credita no cliente
    const { data, error } = await db.client.rpc("process_credit_purchase", {
      p_client_id:      clientId,
      p_amount_brl:     amountBRL,
      p_base_credits:   baseCredits,
      p_bonus_credits:  bonusCredits,
      p_transaction_id: transactionId,
    });

    if (error) throw new Error(`Erro ao processar compra: ${error.message}`);

    // Notifica o painel do cliente em tempo real
    global.io?.to(`client:${clientId}`).emit("credits-added", {
      clientId,
      amountBRL,
      baseCredits,
      bonusCredits,
      totalCredits,
      newBalance: data.new_balance,
      transactionId,
    });

    // Notifica admin
    global.io?.to("admin").emit("purchase-confirmed", {
      clientId,
      amountBRL,
      totalCredits,
      adminNewBalance: data.admin_new_balance,
    });

    console.log(`[Credits] ✅ ${clientId} recebeu ${totalCredits} créditos (R$ ${amountBRL})`);
    return data;
  }

  // ── Adicionar créditos manualmente (pelo admin) ────────────────────────
  async adminAddCredits(clientId, amount, adminId) {
    const { data, error } = await db.client.rpc("admin_add_credits", {
      p_client_id:  clientId,
      p_amount:     amount,
      p_admin_id:   adminId,
      p_description: "admin_manual_add",
    });

    if (error) throw new Error(`Erro ao adicionar créditos: ${error.message}`);
    return data;
  }

  // ── Histórico de transações de créditos ────────────────────────────────
  async getTransactionHistory(clientId, limit = 50) {
    const { data, error } = await db.client
      .from("credit_transactions")
      .select("*")
      .eq("client_id", clientId)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) throw new Error(error.message);
    return data;
  }
}

export const creditService = new CreditService();
